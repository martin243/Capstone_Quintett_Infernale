package de.openhpi.capstone1.counter.controller;

public interface Controller {
	void handleEvent();
}
