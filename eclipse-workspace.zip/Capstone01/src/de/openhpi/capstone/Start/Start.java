package de.openhpi.capstone.Start;

public class Start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello Martin");
		System.out.println("Wow02");
	}

}
