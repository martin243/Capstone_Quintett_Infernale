package de.openhpi.capstone1.abstractfactory;

public class ProductAX extends ProductX {

	public ProductAX() {
		System.out.println("ProductAX created");
	}
	
}
