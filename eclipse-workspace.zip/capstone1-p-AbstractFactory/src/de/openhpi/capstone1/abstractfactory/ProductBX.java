package de.openhpi.capstone1.abstractfactory;

public class ProductBX extends ProductX {
	public ProductBX() {
		System.out.println("ProductBX created");
	}
}
