package de.openhpi.capstone1.abstractfactory;

public abstract class ProductX {
	
}
