package de.openhpi.capstone1.abstractfactory;

public class ProductAY extends ProductY {
	public ProductAY() {
		System.out.println("ProductAY created");
	}
}
