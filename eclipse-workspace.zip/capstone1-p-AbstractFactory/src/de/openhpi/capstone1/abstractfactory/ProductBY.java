package de.openhpi.capstone1.abstractfactory;

public class ProductBY extends ProductY {
	public ProductBY() {
		System.out.println("ProductBY created");
	}
}
