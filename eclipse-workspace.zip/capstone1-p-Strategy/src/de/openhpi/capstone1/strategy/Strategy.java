package de.openhpi.capstone1.strategy;

public interface Strategy {
	void operation();
}
