package de.openhpi.capstone1.strategy;

public class ConcreteStrategy2 implements Strategy {

	@Override
	public void operation() {
		System.out.println("Strategy2");
	}

}
