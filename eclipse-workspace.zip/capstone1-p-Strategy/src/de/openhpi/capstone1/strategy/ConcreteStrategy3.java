package de.openhpi.capstone1.strategy;

public class ConcreteStrategy3 implements Strategy {

	@Override
	public void operation() {
		System.out.println("Strategy3");
	}

}
