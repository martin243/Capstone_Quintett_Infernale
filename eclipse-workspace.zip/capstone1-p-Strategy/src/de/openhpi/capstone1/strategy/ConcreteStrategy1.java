package de.openhpi.capstone1.strategy;

public class ConcreteStrategy1 implements Strategy {

	@Override
	public void operation() {
		System.out.println("Strategy1");
	}

}
