package de.openhpi.capstone1.composite;

public abstract class Component {
	public abstract void operation();
}
