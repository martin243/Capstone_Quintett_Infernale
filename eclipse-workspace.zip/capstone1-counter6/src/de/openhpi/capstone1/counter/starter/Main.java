package de.openhpi.capstone1.counter.starter;

public class Main {

	public static void main(String[] args) {
		TheApp gui = new TheApp();
		gui.init();
	}

}
