
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		game game1 = new game();
		game1.setup();
		game1.draw();
	}

}
